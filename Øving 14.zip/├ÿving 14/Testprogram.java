/**
 * Testprogram.java
 *
 * Øving 14, vår 2014
 */

import java.util.Arrays;

class Testprogram {
	public static void main(String[] args) {
		Staa staatribune1 = new Staa("Ståtribune 1", 30, 100); // String tribunenavn, int kapasitet, int pris
		Staa staatribune2 = new Staa("Ståtribune 2", 20, 200);
		Sitte sittetribune = new Sitte("Sittetribune", 500, 300, 25); // String tribunenavn, int kapasitet, int pris, int antRader
		Vip viptribune = new Vip("VIP-tribune", 20, 500, 2); // String tribunenavn, int kapasitet, int pris, int antRader
		Tribune[] tribuner = {staatribune1, staatribune2, sittetribune, viptribune};
		
		for (int i = 0; i < (tribuner.length - 1); i++) {
			Billett[] billetter = tribuner[i].kjopBilletter(20);
			for (int j = 0; j < billetter.length; j++) {
				System.out.println(billetter[j]);
			}
		}
		
		String[] billetteiere = {"Mia", "David", "Julian", "John Inge", "Magnus"};
		Billett[] billetter = tribuner[3].kjopBilletter(billetteiere);
		
		for (int i = 0; i < billetter.length; i++) {
			System.out.println(billetter[i]);
		}
		
		System.out.println(staatribune1.toString());
		System.out.println(staatribune2.toString());
		System.out.println(sittetribune.toString());
		System.out.println(viptribune.toString());
		
		Arrays.sort(tribuner);
	}
}